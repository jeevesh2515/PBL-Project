//declare all variables
var start = document.getElementById("start");
var quiz = document.getElementById("quiz");
var quizQuestion = document.getElementById("quizQuestion");
var optionA = document.getElementById("choiceA");
var optionB = document.getElementById("choiceB");
var optionC = document.getElementById("choiceC");
var optionD = document.getElementById("choiceD");
var scoreBlock = document.getElementById("scoreBlock");
var scoreMessage = document.getElementById("scoreMessage");
var quizAgain = document.getElementById("quizAgain");
var choices = document.getElementById("choices");
var choiceResponse = document.getElementById("choiceResponse");
var score = 0;

//questions function so our getQuestion function later can get the right value from array

let questions = [{
    question: "State which block contains information about the file system like size of file system, block size",
    
    choiceA: "data block",
    choiceB: "inode",
    choiceC: "super block",
    choiceD: "boot block",
    correctAnswer: "C"
}, {
    question: "List the correct comparison statement in Linux shell Scripting? ",
    choiceA: "if $x-gt $y",
    choiceB: "if [$x-gt $y]",
    choiceC: "if ($x-gt $y)",
    choiceD: "None",
    correctAnswer: "B"
}, {
    question: "How to get input from the terminal for shell script?",
    choiceA: "'scan' command",
    choiceB: "'read' command",
    choiceC: "'input' command",
    choiceD: "None",
    correctAnswer: "A"
}, {
    question: "Identify the invalid shell variable?   ",
    choiceA: "_san",
    choiceB: "san_2",
    choiceC: "_san_2",
    choiceD: "2_san",
    correctAnswer: "D"
}, {
    question: "Select the Command is used to print the value of a variable?",
    choiceA: "Get",
    choiceB: "Echo",
    choiceC: "Expr",
    choiceD: "$",
    correctAnswer: "B"
}, {
    question: "List which statement is supported in unix shell? ",
    choiceA: "Case",
    choiceB: "Switch",
    choiceC: "switch...case",
    choiceD: "case...esac",
    correctAnswer: "D"
}, {
    question: "List name of a variable can contain ________. ",
    choiceA: "Numbers",
    choiceB: "Letters",
    choiceC: "underscore character",
    choiceD: "All of the above",
    correctAnswer: "D"
}, {
    question: "Shell variables are of how many types?",
    choiceA: "3",
    choiceB: "4",
    choiceC: "5",
    choiceD: "2",
    correctAnswer: "D"
}, {
    question: "In relational operator, which keyword is used to represent greater than or equal?",
    choiceA: "-eq",
    choiceB: "-gte",
    choiceC: "-ge",
    choiceD: "-gt",
    correctAnswer: "C"
}, {
    question: "which command identifies the resource of a command?",
    choiceA: "type",
    choiceB: "typeset",
    choiceC: "select",
    choiceD: "source",
    correctAnswer: "A"
}, ];


var questionIndex = 0;


// getQuestion function

function getQuestion() {

    choiceResponse.style.display = "none";
    let q = questions[questionIndex];
    quizQuestion.innerHTML = "<p>Question " +(questionIndex+1) + ": " + q.question + "</p>";
   
    optionA.innerHTML = q.choiceA;
    optionB.innerHTML = q.choiceB;
    optionC.innerHTML = q.choiceC;
    optionD.innerHTML = q.choiceD;
    choices.style.display = "block";
}


// start quiz

function beginQuiz() {
    start.style.display ="none";
    getQuestion();
    quiz.style.display = "block";
}

// show score function

function showScore() {
    quiz.style.display = "none";
    scoreBlock.style.display = "block";
    scoreBlock.innerHTML = "<p> You scored " + score + " out of 10!</p>";

    if (score < 4) {
        scoreMessage.innerHTML = "<p>Not so good! Time for some revision.</p>";
    }
    else if (score < 8) {
        scoreMessage.innerHTML = "<p>Pretty good! But still room for improvement.</p>"
    }
    else {
        scoreMessage.innerHTML = "<p>Great work! You really know about Shell Programming!</p>"
    }
    scoreMessage.style.display = "block";
    quizAgain.style.display = "block";
}


//function to check if answer is correct

function check(answer) {
    if (questionIndex < questions.length - 1) {
        if (answer == questions[questionIndex].correctAnswer) {
            score++;
            questionIndex++;
            choices.style.display = "none";
            choiceResponse.innerHTML= "<p>Correct!</p>"
            choiceResponse.style.display = "block";
            setTimeout(getQuestion,2000);
        }
        else {
            questionIndex++;
            choices.style.display = "none";
            choiceResponse.innerHTML= "<p>Incorrect!</p>"
            choiceResponse.style.display = "block";
            setTimeout(getQuestion,2000);
        }
    }
    else {
        if (answer == questions[questionIndex].correctAnswer) {
            score++;
            choices.style.display = "none";
            choiceResponse.innerHTML= "<p>Correct!</p>"
            choiceResponse.style.display = "block";
            setTimeout(showScore,2000);
        }
        else {
            choices.style.display = "none";
            choiceResponse.innerHTML= "<p>Inorrect!</p>"
            choiceResponse.style.display = "block";
            setTimeout(showScore,2000);
        }
    }
}

function restartQuiz() {
    start.style.display = "block";
    scoreBlock.style.display = "none";
    scoreMessage.style.display = "none";
    quizAgain.style.display = "none";
    score = 0;
    questionIndex = 0;
}
