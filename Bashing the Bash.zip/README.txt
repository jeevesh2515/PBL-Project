this is a simple program for a website to redirect it to an online compiler or to take a test on Subjective LINUX Questions.

For redirecting it to an online compiler open the file: file.html
 
For Taking the subjective test and saving it in the database first you have to create a database and then you have to open the file:
index.php

For now we have linked only one question with the database and the rest are redirected to the online compiler
so, as per requirements you can change it. 