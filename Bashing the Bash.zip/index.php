<?php

$insert = false;
error_reporting(0);
$server = "localhost";
$username = "root";
$password = "";

$con = mysqli_connect($server, $username, $password);

if (!$con) {
    die("connection to this database failed due to" . mysqli_connect_error());
}

mysqli_select_db($con, 'bash_shell');

$q1 = $_POST['q1'];
$q2 = $_POST['q2'];
$q3 = $_POST['q3'];
$q4 = $_POST['q4'];
$q5 = $_POST['q5'];

$query = "INSERT INTO answers (q1, q2, q3, q4, q5, dt) VALUES ('$q1', '$q2', '$q3', '$q4', '$q5', current_timestamp()) ";

mysqli_query($con, $query);

if ($con->query($sql) == true) {
    $insert = true;
} else {
    echo "ERROR: $sql <br> $con->error";
}
$con->close();

?>

<!DOCTYPE html>
<html>

<head>
    <title>Bashing The Bash</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="backg.css">

    <style>
        .txtcolor {

            color: rgb(252, 252, 220);

        }

        .txtalign {

            text-align: center;
            padding: 30px;

        }

        .txtstyle {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: larger;
            font-style: oblique;
            font-weight: bold;
            padding-top: 80px;
            line-height: 200%;
        }
    </style>

</head>

<body>
    <div id="container">
        <div class="backgr">
            <audio controls preload="none" loop>
                <source src="videoplayback.mp4" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
            <div class="txtalign">
                <div class="h1">
                    <p><span style="background-color: teal;"> Bash Shell Script</span></p>
                </div>

                <div class="txtstyle">
                    <?php
                    if($insert == true)
                        echo "<p class='submitmsg'>Thanks For Submitting the
                            Form!</p>"     
                    ?>
                    <div class="txtcolor">
                        <form action="index.php" method="post">
                            <p>Q1. Implement a shell script program to input marks of five subjects calculate and print
                                total,
                                percentage and
                                grade.</p>

                            <form method="post" action="https://www.jdoodle.com/api/redirect-to-post/test-bash-shell-script-online">


                                <textarea name="q1" id="q1" cols="80" rows="8" placeholder="Enter your answer"></textarea>



                                <input type="submit" value="Test">
                            </form>
                            <p>Q2. Write a shell script program to print multiplication table using loop.</p>

                            <form method="post" action="https://www.jdoodle.com/api/redirect-to-post/test-bash-shell-script-online">


                                <textarea name="q2" id="q2" cols="80" rows="8" placeholder="Enter your answer"></textarea>


                                <input type="submit" value="Test">
                            </form>
                            <p>Q3. Write a shell script Program to implement the numerical series below using loop.<br>
                                11111<br>
                                22222<br>
                                33333</p>

                            <form method="post" action="https://www.jdoodle.com/api/redirect-to-post/test-bash-shell-script-online">


                                <textarea name="q3" id="q3" cols="80" rows="8" placeholder="Enter your answer"></textarea>

                                <input type="submit" value="Test">
                            </form>
                            <p>Q4. Write a shell script program to print Fibonacci series.</p>

                            <form method="post" action="https://www.jdoodle.com/api/redirect-to-post/test-bash-shell-script-online">

                                <textarea name="q4" id="q4" cols="80" rows="8" placeholder="Enter your answer"></textarea>

                                <input type="submit" value="Test">
                            </form>
                            <p>Q5. Implement a script which accepts an integer input from the user and determines
                                whether
                                the
                                integer is
                                zero,
                                negative, odd or even number:</p>

                            <form method="post" action="https://www.jdoodle.com/api/redirect-to-post/test-bash-shell-script-online">

                                <textarea name="q5" id="q5" cols="80" rows="8" placeholder="Enter your answer"></textarea>

                                <input type="submit" value="Test">
                            </form>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>